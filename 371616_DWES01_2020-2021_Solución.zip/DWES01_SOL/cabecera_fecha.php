<div style='text-align:right'>
    Fecha de hoy: <?=date_format(date_create(),'d/m/Y')?>
</div>
