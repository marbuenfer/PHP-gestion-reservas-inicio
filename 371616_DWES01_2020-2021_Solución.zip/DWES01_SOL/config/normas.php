<?php

define ('NORMAS_DIR','normas/');
$normas=[
    'np' => 'normas_piscina.html',
    'ng' => 'normas_gimnasio.html',
    'ns' => 'normas_sala.html',
];